%% This is an empty file. Its existence is used by the generating script 
% to determine if a subfolder consists of Multiple Choice question or other
% type of assignments