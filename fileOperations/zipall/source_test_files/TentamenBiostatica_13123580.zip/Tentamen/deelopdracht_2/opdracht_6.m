%% =========== BLIJF VAN HET ONDERSTAANDE CODE COMMENTAAR AF! =============
%                    |243826efbc23d7af964a7a6ae13b9306|
%                            Tentamen_1712052135
%                              Deelpunten: 3
%
% LEES DE VOLGENDE REGELS:
%
% 1 -   De volgende door ons aangemaakte zaken mag jij NIET aanpassen:
%                           A: Bestandsnamen
%                           B: Door ons aangemaakt commentaar
%                           C: Folders en folderstructuur
%                           D: De code in deze codesectie
% 2 -   Als dit bestand niet uit te voeren valt, bijvoorbeeld doordat je
%       tijdens het uitvoeren een foutmelding krijgt, krijg je GEEN punten!
% 3 -   Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 -   Je maakt de opdracht in dit bestand. Vul het bestand alleen met
%       voor de opdracht nuttige code. Doe je dit niet dan kan dat een
%       vermindering van het te verdienen aantal punten als gevolg hebben.
% 5 -   Door jou geschreven commentaar regels (met %% of %) worden niet
%       door ons gelezen of gebruikt. 
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een FUNCTIE. De
% specifieke opdracht staat hieronder.
%
%
%% =========== BLIJF VAN HET BOVENSTAANDE CODE COMMENTAAR AF! =============
 
%% Opdracht 6
% Maak een functie aan met de naam: 'opdracht_6'. 

% Deze functie heeft 1 input: een 3x3 matrix met de naam Matrix
% Deze functie heeft 3 outputs: de eerste kolomvector, 
% de tweede kolomvector en de derde kolomvector van de Matrix.  

% De drie output variabelen geef je de volgende namen mee:
% eersteKolomVector,tweedeKolomVector,derdeKolomVector

% Maak deze functie aan.

function [eersteKolomvector, tweedeKolomvector, derdeKolomvector] = opdracht_6(Matrix)


eersteKolomvector = Matrix(1:3,1)
tweedeKolomvector = Matrix(1:3,2)
derdeKolomvector = Matrix(1:3,3)
