teller = 1

while teller < 100
    teller = teller + 1
    
end
clear
