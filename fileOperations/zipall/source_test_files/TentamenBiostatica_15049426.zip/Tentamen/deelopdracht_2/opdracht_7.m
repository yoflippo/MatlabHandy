%% =========== BLIJF VAN HET ONDERSTAANDE CODE COMMENTAAR AF! =============
%                    |eec43fcc39454c5e06f5d371ec0a4b9e|
%                            Tentamen_1712052135
%                              Deelpunten: 3
%
% LEES DE VOLGENDE REGELS:
%
% 1 -   De volgende door ons aangemaakte zaken mag jij NIET aanpassen:
%                           A: Bestandsnamen
%                           B: Door ons aangemaakt commentaar
%                           C: Folders en folderstructuur
%                           D: De code in deze codesectie
% 2 -   Als dit bestand niet uit te voeren valt, bijvoorbeeld doordat je
%       tijdens het uitvoeren een foutmelding krijgt, krijg je GEEN punten!
% 3 -   Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 -   Je maakt de opdracht in dit bestand. Vul het bestand alleen met
%       voor de opdracht nuttige code. Doe je dit niet dan kan dat een
%       vermindering van het te verdienen aantal punten als gevolg hebben.
% 5 -   Door jou geschreven commentaar regels (met %% of %) worden niet
%       door ons gelezen of gebruikt. 
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een FUNCTIE. De
% specifieke opdracht staat hieronder.
%
%
%% =========== BLIJF VAN HET BOVENSTAANDE CODE COMMENTAAR AF! =============
 
%% Opdracht 7
% Maak een functie 'opdracht_7' met een inputvariabele
% genaamd 'hoek'. Deze input geef je op in radialen.
%
% Deze functie geeft de cosinus en sinus terug in twee aparte output 
% variabelen en in deze volgorde. 

[sin, cos]= opdracht_7('hoek')%in radialen