%% =========== BLIJF VAN HET ONDERSTAANDE CODE COMMENTAAR AF! =============
%                    |333f6e0f6ab917c82d4dca0eca0eb1ca|
%                            Tentamen_1712052135
%                              Deelpunten: 4
%
% LEES DE VOLGENDE REGELS:
%
% 1 -   De volgende door ons aangemaakte zaken mag jij NIET aanpassen:
%                           A: Bestandsnamen
%                           B: Door ons aangemaakt commentaar
%                           C: Folders en folderstructuur
%                           D: De code in deze codesectie
% 2 -   Als dit bestand niet uit te voeren valt, bijvoorbeeld doordat je
%       tijdens het uitvoeren een foutmelding krijgt, krijg je GEEN punten!
% 3 -   Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 -   Je maakt de opdracht in dit bestand. Vul het bestand alleen met
%       voor de opdracht nuttige code. Doe je dit niet dan kan dat een
%       vermindering van het te verdienen aantal punten als gevolg hebben.
% 5 -   Door jou geschreven commentaar regels (met %% of %) worden niet
%       door ons gelezen of gebruikt. 
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een FUNCTIE. De
% specifieke opdracht staat hieronder.
%
%
%% =========== BLIJF VAN HET BOVENSTAANDE CODE COMMENTAAR AF! =============
 
%% Opdracht 10
% Maak een functie met 2 inputs genaamd 'vector' (een vector) en 
% 'kleinerdan' (een getal) Zorg dat de functie alle getallen in 'vector'
% die kleiner zijn dan de waarde in de inputvariabele 'kleinerdan' gelijk 
% aan -1 maakt. 
%
% Als je dat hebt gedaan, zorg dat de functie deze vector teruggeeft EN
% er een plot van maakt.
%
% Je mag de waarde van een inputvariabele NIET aanpassen. 
%
% Noem de functie: 'opdracht_10'.

[vector < kleinerdan] = opdracht_10(vector, kleinderdan)
plot(opdracht_10)
