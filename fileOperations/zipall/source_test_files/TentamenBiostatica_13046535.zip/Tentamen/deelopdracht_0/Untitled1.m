n = 1;                                                   
				t = -n:0.1:n;                                            
				Y1 = t.^2;                                               
				                                                         
				figure;                                                  
				plot(t,Y1,'ro','LineWidth',3);