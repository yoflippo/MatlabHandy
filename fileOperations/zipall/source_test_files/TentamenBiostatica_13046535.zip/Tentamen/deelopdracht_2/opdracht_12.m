%% =========== BLIJF VAN HET ONDERSTAANDE CODE COMMENTAAR AF! =============
%                    |53ed65e9f283dc32e372f0419a0bc6f6|
%                            Tentamen_1712052135
%                              Deelpunten: 4
%
% LEES DE VOLGENDE REGELS:
%
% 1 -   De volgende door ons aangemaakte zaken mag jij NIET aanpassen:
%                           A: Bestandsnamen
%                           B: Door ons aangemaakt commentaar
%                           C: Folders en folderstructuur
%                           D: De code in deze codesectie
% 2 -   Als dit bestand niet uit te voeren valt, bijvoorbeeld doordat je
%       tijdens het uitvoeren een foutmelding krijgt, krijg je GEEN punten!
% 3 -   Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 -   Je maakt de opdracht in dit bestand. Vul het bestand alleen met
%       voor de opdracht nuttige code. Doe je dit niet dan kan dat een
%       vermindering van het te verdienen aantal punten als gevolg hebben.
% 5 -   Door jou geschreven commentaar regels (met %% of %) worden niet
%       door ons gelezen of gebruikt. 
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een SCRIPT. De
% specifieke opdracht staat hieronder.
%
% LET OP!
% Exacte naamgeving is heel belangrijk! Merk bv. het verschil op tussen
% de variabelen: 'Ab', 'aB' en 'ab'. Matlab maakt onderscheid tussen kleine
% letters en hoofdletters.
%
%% =========== BLIJF VAN HET BOVENSTAANDE CODE COMMENTAAR AF! =============
 
% Gegeven: een rijvector met tijdstippen waarop een rugbyspeler een bal
% vast heeft (1) en de bal door niemand wordt vastgehouden (0).
%
% De positie van de bal in voorwaartse richting (de x-coordinaat)
% wordt gegeven in Pos. 
% Geef de indexen van de tijdstippen waarop een speler de bal vast heeft en 
% naar achter rent. Zo'n tijdstip wordt gedefinieerd als een tijdstip i 
% waarbij de positie op het volgende tijdstip i+1 kleiner is dan op
% tijdstip i. Op tijdstip i en op i+1 moet hij de bal vast hebben.
%
% Dus, geef een logical vector met de naam
% 'vastNaarAchter' die enen bevat op de tijdstippen waarop de speler met de
% bal naar achter loopt en nullen als hij naar voren loopt of niemand de 
% bal vast heeft.

close all
balVast = logical([1 1 1 1 1 0 0 0 0 0 0 0 0 1 1 1]);
Pos = [30 31 33 35 38 36 34 32 30 28 26 24 22 22 23 24];
vastNaarAchter = logical([])