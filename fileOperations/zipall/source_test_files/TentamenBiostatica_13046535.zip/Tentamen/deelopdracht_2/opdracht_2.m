%% =========== BLIJF VAN HET ONDERSTAANDE CODE COMMENTAAR AF! =============
%                    |21833d10b4ffa7a7e018132921c79b9a|
%                            Tentamen_1712052135
%                              Deelpunten: 1
%
% LEES DE VOLGENDE REGELS:
%
% 1 -   De volgende door ons aangemaakte zaken mag jij NIET aanpassen:
%                           A: Bestandsnamen
%                           B: Door ons aangemaakt commentaar
%                           C: Folders en folderstructuur
%                           D: De code in deze codesectie
% 2 -   Als dit bestand niet uit te voeren valt, bijvoorbeeld doordat je
%       tijdens het uitvoeren een foutmelding krijgt, krijg je GEEN punten!
% 3 -   Elke variabele waar 'NaN' aan wordt toegekend moet JIJ bewerken.
% 4 -   Je maakt de opdracht in dit bestand. Vul het bestand alleen met
%       voor de opdracht nuttige code. Doe je dit niet dan kan dat een
%       vermindering van het te verdienen aantal punten als gevolg hebben.
% 5 -   Door jou geschreven commentaar regels (met %% of %) worden niet
%       door ons gelezen of gebruikt. 
% 
% Opdrachtbeschrijving:
% Deze opdracht bestaat uit het schrijven/aanvullen van een SCRIPT. De
% specifieke opdracht staat hieronder.
%
% LET OP!
% Exacte naamgeving is heel belangrijk! Merk bv. het verschil op tussen
% de variabelen: 'Ab', 'aB' en 'ab'. Matlab maakt onderscheid tussen kleine
% letters en hoofdletters.
%
%% =========== BLIJF VAN HET BOVENSTAANDE CODE COMMENTAAR AF! =============
 
%% Opdracht 2
% Maak de volgende variabelen aan:
%   A met de waarde 1;
%   B met de waarde 0;
%   C met de waarde 1;
%   Combineer bovengenoemde variabelen m.b.v. de OR- of AND-operator zodat
%   ze allemaal worden gebruikt en worden geevalueerd tot '0'. Het
%   resultaat van deze handeling moet worden toegekend aan een variabele
%   genaamd 'resultaat'.
A = 1;
B = 0;
C = 1;
resultaat = A && B && C
