deelpunten = 2;
